﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace game_of_life_yousuf
{
    class Grid
    {
        int row;
        public Grid(int row)
        {
            this.row = row;
        }

        /*
         * This method creates a 2D array of Cell objects
         * Arguments: None
         */
        public Cell[,] Create2dArray()
        {
            bool correctVal = true;
            Cell[,] origArray;
            while (correctVal == true)
            {
                try
                {
                    // declare 2D arrays and variables
                    Console.Write("How many rows would you like in the array: ");
                    int rows = Convert.ToInt32(Console.ReadLine());
                    Console.Write("How many columns would you like in the array: ");
                    int columns = Convert.ToInt32(Console.ReadLine());
                    origArray = new Cell[rows, columns];

                    PopulateRandom(origArray);
                    correctVal = false;

                    return origArray;

                }

                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    
                }
            }
            origArray = new Cell[0, 0];
            return origArray;
        }

        /*
         * This method creates a cell object at each index and gives it a value of either 0 or 1
         * Arguments: Original 2D array of cell objects 
         */
        public void PopulateRandom(Cell[,] origArray)
        {
            // generate either a 0 or 1 for each cell object
            Random rnd = new Random();

            // for loops that create a cell object and populate each index with a cell object
            for (int i = 0; i < origArray.GetLength(0); i++)
            {
                for (int j = 0; j < origArray.GetLength(1); j++)
                {
                    int rndVal = rnd.Next(2);
                    origArray[i, j] = new Cell(rndVal, i, j); // the object has a random value of 0 or 1, and then also sends the position in the 2d array
                }
            }

            try
            {
                // for loops that get the value of the neighbours for the current cell object at that index
                for (int i = 0; i < origArray.GetLength(0); i++)
                {
                    for (int j = 0; j < origArray.GetLength(1); j++)
                    {
                        origArray[i, j].GetNeighbours(origArray);
                    }
                }
            }

            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        public void Print2dArray(Cell[,] array)
        {
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    if (j == array.GetLength(1) - 1)
                    {
                        Console.Write(array[i, j]);
                    }

                    else
                    {
                        Console.Write(array[i, j] + ", ");
                    }
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }
    }
}
